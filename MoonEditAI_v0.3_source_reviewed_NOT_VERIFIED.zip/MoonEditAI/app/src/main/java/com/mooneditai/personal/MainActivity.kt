package com.mooneditai.personal

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@UnstableApi
class MainActivity : Activity() {

    private lateinit var playerView: PlayerView
    private lateinit var statusText: TextView
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var startValueText: TextView
    private lateinit var endValueText: TextView
    private lateinit var playButton: Button
    private lateinit var exportButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var trimRangeView: TrimRangeView

    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private var durationMs = 0L
    private var startMs = 0L
    private var endMs = 0L
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private var exporting = false

    private val progressRunnable = object : Runnable {
        override fun run() {
            val activeTransformer = transformer
            if (exporting && activeTransformer != null) {
                try {
                    if (activeTransformer.getProgress(progressHolder) ==
                        Transformer.PROGRESS_STATE_AVAILABLE
                    ) {
                        progressBar.progress = progressHolder.progress
                        statusText.text = "Exporting… ${progressHolder.progress}%"
                    }
                } catch (_: IllegalStateException) {
                    // Transformer may have completed between the poll and callback.
                }
                handler.postDelayed(this, 300L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = true
        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val actual = player?.duration ?: 0L
                    if (actual > 0 && actual != durationMs) {
                        durationMs = actual
                        if (endMs == 0L || endMs > durationMs) endMs = durationMs
                        trimRangeView.setRange(durationMs, startMs, endMs)
                        updateTimes()
                    }
                }
                if (playbackState == Player.STATE_ENDED) {
                    player?.seekTo(startMs)
                    player?.pause()
                    updatePlayButton()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()
        })
        handler.post(progressTicker)
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && selectedUri != null && durationMs > 0) {
                val current = p.currentPosition.coerceIn(0L, durationMs)
                positionText.text = formatTime(current)
                if (p.isPlaying && current >= endMs) {
                    p.pause()
                    p.seekTo(startMs)
                }
            }
            handler.postDelayed(this, 200L)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(11, 16, 32))
        }

        val title = TextView(this).apply {
            text = "MOONEDIT AI"
            textSize = 22f
            setTextColor(Color.WHITE)
            letterSpacing = 0.12f
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PERSONAL EDITION  •  VIDEO TRIM"
            textSize = 11f
            setTextColor(Color.rgb(160, 158, 205))
            setPadding(0, dp(3), 0, dp(12))
        }
        root.addView(subtitle, matchWrap())

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f
        ).apply { bottomMargin = dp(12) })

        val importButton = makeButton("＋  Import video").apply {
            setOnClickListener { openVideoPicker() }
        }
        root.addView(importButton, matchWrap())

        val timeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(6))
        }
        positionText = makeLabel("00:00.0")
        durationText = makeLabel("00:00.0")
        timeRow.addView(positionText, LinearLayout.LayoutParams(0, dp(32), 1f))
        timeRow.addView(durationText, LinearLayout.LayoutParams(0, dp(32), 1f).apply {
            gravity = Gravity.END
        })
        root.addView(timeRow, matchWrap())

        trimRangeView = TrimRangeView(this).apply {
            onRangeChanged = { start, end ->
                startMs = start
                endMs = end
                updateTimes()
            }
        }
        root.addView(trimRangeView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(76)
        ))

        val rangeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val startLabel = TextView(this).apply {
            text = "START"
            textSize = 10f
            setTextColor(Color.rgb(154, 160, 190))
        }
        val endLabel = TextView(this).apply {
            text = "END"
            textSize = 10f
            setTextColor(Color.rgb(154, 160, 190))
            gravity = Gravity.END
        }
        rangeRow.addView(startLabel, LinearLayout.LayoutParams(0, dp(20), 1f))
        rangeRow.addView(endLabel, LinearLayout.LayoutParams(0, dp(20), 1f))
        root.addView(rangeRow, matchWrap())

        val valueRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startValueText = TextView(this).apply {
            text = "00:00.0"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        endValueText = TextView(this).apply {
            text = "00:00.0"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        valueRow.addView(startValueText, LinearLayout.LayoutParams(0, dp(26), 1f))
        valueRow.addView(endValueText, LinearLayout.LayoutParams(0, dp(26), 1f))
        root.addView(valueRow, matchWrap())

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        playButton = makeButton("▶  Play")
        playButton.setOnClickListener { togglePlayback() }
        actionRow.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            rightMargin = dp(8)
        })
        exportButton = makeButton("Export MP4").apply {
            setOnClickListener { exportTrimmedVideo() }
        }
        actionRow.addView(exportButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(actionRow, matchWrap())

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(6)
        ).apply { topMargin = dp(10) })

        statusText = TextView(this).apply {
            text = "Import a video to begin."
            textSize = 12f
            setTextColor(Color.rgb(177, 181, 207))
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(statusText, matchWrap())
        setContentView(root)
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_PICK_VIDEO)
    }

    @Deprecated("Uses ACTION_OPEN_DOCUMENT for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_VIDEO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers issue only a temporary grant.
            }
            loadVideo(uri)
        }
    }

    private fun loadVideo(uri: Uri) {
        selectedUri = uri
        durationMs = 0L
        startMs = 0L
        endMs = 0L
        statusText.text = "Loading video…"
        val item = MediaItem.fromUri(uri)
        player?.apply {
            stop()
            clearMediaItems()
            setMediaItem(item)
            prepare()
            playWhenReady = false
        }
        playerView.visibility = View.VISIBLE
        updatePlayButton()
    }

    private fun togglePlayback() {
        val p = player ?: return
        if (selectedUri == null) {
            Toast.makeText(this, "Import a video first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.currentPosition < startMs || p.currentPosition >= endMs) p.seekTo(startMs)
            p.play()
        }
        updatePlayButton()
    }

    private fun updatePlayButton() {
        if (::playButton.isInitialized) {
            playButton.text = if (player?.isPlaying == true) "Ⅱ  Pause" else "▶  Play"
        }
    }

    private fun updateTimes() {
        if (!::positionText.isInitialized) return
        positionText.text = formatTime(player?.currentPosition ?: 0L)
        durationText.text = formatTime(durationMs)
        startValueText.text = formatTime(startMs)
        endValueText.text = formatTime(endMs)
    }

    private fun exportTrimmedVideo() {
        val uri = selectedUri
        if (uri == null || durationMs <= 0L) {
            Toast.makeText(this, "Please import a video first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (endMs - startMs < MIN_CLIP_MS) {
            Toast.makeText(this, "Select at least a 1-second clip.", Toast.LENGTH_LONG).show()
            return
        }
        if (exporting) return

        val outputDir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "MoonEditAI")
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            statusText.text = "Could not create export folder."
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val tempFile = File(outputDir, "MoonEdit_$stamp.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val clippedItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clipping)
            .build()

        exporting = true
        exportButton.isEnabled = false
        progressBar.progress = 0
        progressBar.visibility = View.VISIBLE
        statusText.text = "Preparing export…"
        val activeTransformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    exporting = false
                    handler.removeCallbacks(progressRunnable)
                    progressBar.progress = 100
                    publishToMovies(tempFile)
                    transformer = null
                    exportButton.isEnabled = true
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    exporting = false
                    handler.removeCallbacks(progressRunnable)
                    tempFile.delete()
                    transformer = null
                    exportButton.isEnabled = true
                    progressBar.visibility = View.GONE
                    statusText.text = "Export failed: ${exportException.message ?: "Unsupported video"}"
                    Toast.makeText(this@MainActivity, "Export failed.", Toast.LENGTH_LONG).show()
                }
            })
            .build()
        transformer = activeTransformer
        try {
            activeTransformer.start(clippedItem, tempFile.absolutePath)
            handler.post(progressRunnable)
        } catch (e: Exception) {
            exporting = false
            transformer = null
            exportButton.isEnabled = true
            progressBar.visibility = View.GONE
            tempFile.delete()
            statusText.text = "Could not start export: ${e.message}"
        }
    }

    private fun publishToMovies(tempFile: File) {
        Thread {
            var savedUri: Uri? = null
            try {
                val name = tempFile.name
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/MoonEdit AI")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val destination = contentResolver.insert(collection, values)
                    ?: throw IOException("MediaStore could not create output")
                savedUri = destination
                contentResolver.openOutputStream(destination)?.use { output ->
                    FileInputStream(tempFile).use { input -> input.copyTo(output) }
                } ?: throw IOException("Could not open output stream")
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(destination, done, null, null)
                tempFile.delete()
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    statusText.text = "Export complete • Movies/MoonEdit AI/${tempFile.name}"
                    Toast.makeText(this, "Saved to Movies/MoonEdit AI", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                savedUri?.let { contentResolver.delete(it, null, null) }
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    statusText.text = "Export created, but could not publish to Movies: ${e.message}. Temp: ${tempFile.absolutePath}"
                }
            }
        }.start()
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(89, 76, 190)))
    }

    private fun makeLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun formatTime(ms: Long): String {
        val safe = max(0L, ms)
        val minutes = safe / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val tenths = (safe % 1_000L) / 100L
        return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        handler.removeCallbacks(progressRunnable)
        if (isFinishing && exporting) {
            try { transformer?.cancel() } catch (_: Exception) {}
        }
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_VIDEO = 4102
        private const val MIN_CLIP_MS = 1_000L
    }
}

/**
 * Compact two-handle timeline. The handles cannot cross and always retain
 * at least one second between them.
 */
private class TrimRangeView(context: android.content.Context) : View(context) {
    var onRangeChanged: ((Long, Long) -> Unit)? = null
    private var duration = 0L
    private var start = 0L
    private var end = 0L
    private val density = resources.displayMetrics.density
    private val trackPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(57, 65, 91)
        strokeWidth = 7f * density
        strokeCap = android.graphics.Paint.Cap.ROUND
    }
    private val selectedPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(139, 124, 255)
        strokeWidth = 7f * density
        strokeCap = android.graphics.Paint.Cap.ROUND
    }
    private val handlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = android.graphics.Paint.Style.FILL
    }
    private var activeHandle = 0
    private val handleRadius = 10f * density
    private val horizontalPad = 18f * density
    private val minimumMs = 1_000L

    fun setRange(total: Long, from: Long, to: Long) {
        duration = max(0L, total)
        if (duration <= 0L) {
            start = 0L
            end = 0L
        } else {
            start = from.coerceIn(0L, max(0L, duration - minimumMs))
            end = to.coerceIn(min(duration, start + minimumMs), duration)
            if (end - start < minimumMs) {
                start = max(0L, end - minimumMs)
            }
        }
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val y = height / 2f
        val left = horizontalPad
        val right = width - horizontalPad
        canvas.drawLine(left, y, right, y, trackPaint)
        if (duration > 0L) {
            val sx = xFor(start)
            val ex = xFor(end)
            canvas.drawLine(sx, y, ex, y, selectedPaint)
            canvas.drawCircle(sx, y, handleRadius, handlePaint)
            canvas.drawCircle(ex, y, handleRadius, handlePaint)
        }
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (duration <= 0L) return false
        when (event.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                val sx = xFor(start)
                val ex = xFor(end)
                activeHandle = if (kotlin.math.abs(event.x - sx) <= kotlin.math.abs(event.x - ex)) 0 else 1
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromTouch(event.x)
                return true
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                updateFromTouch(event.x)
                return true
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                updateFromTouch(event.x)
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun updateFromTouch(x: Float) {
        val fraction = ((x - horizontalPad) / max(1f, width - 2f * horizontalPad)).coerceIn(0f, 1f)
        val value = (fraction * duration).toLong()
        if (activeHandle == 0) {
            start = value.coerceIn(0L, max(0L, end - minimumMs))
        } else {
            end = value.coerceIn(min(duration, start + minimumMs), duration)
        }
        invalidate()
        onRangeChanged?.invoke(start, end)
    }

    private fun xFor(value: Long): Float {
        if (duration <= 0L) return horizontalPad
        return horizontalPad + (width - 2f * horizontalPad) * (value.toFloat() / duration.toFloat())
    }
}

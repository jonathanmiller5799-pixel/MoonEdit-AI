# MoonEdit AI — Personal Edition (v0.3)

Video Preview + Trim/Cut milestone for Android.

## Features
- Import a video using Android's system document picker (`ACTION_OPEN_DOCUMENT`, `video/*`).
- In-app playback using AndroidX Media3 ExoPlayer / PlayerView.
- Play, pause, seek, current position and duration.
- Two-handle trim timeline with enforced handle ordering and a minimum 1-second selection.
- Real MP4 export using AndroidX Media3 Transformer clipping.
- Export is written to the public `Movies/MoonEdit AI/` collection through MediaStore. The original source is never modified.
- No broad storage permission is requested. The document picker grants access to the chosen item only.

## Build
1. Open this folder in Android Studio (JDK 17).
2. Install Android SDK Platform 36 and Build Tools 36.x from SDK Manager.
3. Allow Gradle sync to download dependencies.
4. Run the `app` configuration on a device or build with:
   `gradle :app:assembleDebug`

This source archive currently contains `gradle-wrapper.properties` but not the Gradle wrapper JAR/scripts. Use an installed Gradle 8.13 or generate the wrapper in Android Studio (`gradle wrapper --gradle-version 8.13`) before relying on `./gradlew`.

The reviewed project configuration uses Android Gradle Plugin 8.13.2, Kotlin Gradle Plugin 2.3.20, Gradle 8.13, JDK 17, compile/target SDK 36, and AndroidX Media3 1.11.1. Kotlin 2.2.20 was changed because the official Kotlin compatibility table lists AGP 8.13.2 outside its fully supported AGP range (up to 8.11.1).

## Output
Successful exports appear in:
`Movies/MoonEdit AI/`

The app uses a temporary file under its app-specific Movies directory during export, then copies it into MediaStore and removes the temporary file.

## Notes / limitations
- Transformer may re-encode some input formats and may fail for unsupported codecs/containers. MP4 output is requested.
- Export processing is device-dependent. 1080p should be practical on the Galaxy A15 5G for typical supported codecs, but export speed and supported profiles depend on the hardware encoder.
- A cut is accurate to Media3's supported sample/frame boundaries; codec keyframe structure can affect exact cut precision.
- Keep the app open while exporting in this milestone. Background/foreground service export is not included.
- Build verification was not possible in the review environment: Java 21 is present, but Android SDK, Gradle executable, emulator/ADB, and network access to download them are unavailable. Therefore no APK or device workflow has been verified.
